LK_FB - Deploy-ready package
============================
This package is a minimal, deploy-ready Next.js structure with important safety defaults for Vercel.

Quick local test:
  1. Install dependencies: npm install
  2. Create a .env.local file from .env.example and fill keys
  3. Run locally: npm run dev
  4. Build: npm run build
  5. Start: npm run start

To deploy on Vercel:
  1. Go to https://vercel.com and sign in.
  2. Create a new project and upload this ZIP or link your repo.
  3. Add environment variables from .env.example in Project Settings.
  4. Deploy — the site will be live at <your-project>.vercel.app

Notes:
  - Replace Stripe keys before using real payments.
  - This project includes API stubs under /api for moderation, orders, and notifications.
  - If using large media files, host them on S3 or a CDN and link from the frontend.
