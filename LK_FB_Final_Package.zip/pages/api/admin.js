export default function handler(req,res){
  // placeholder admin endpoints: list flags, bans, health
  res.status(200).json({flags:[], bans:[]});
}
