let USERS = [];
export default function handler(req, res) {
  if(req.method === 'POST') {
    const { action } = req.query;
    if(action === 'signup') {
      const { email, password } = req.body;
      if(!email || !password) return res.status(400).json({error:'missing'});
      USERS.push({email,password,created:Date.now()});
      return res.status(201).json({ok:true});
    }
  }
  res.status(405).end();
}
