export default function handler(req, res) {
  const { content } = req.body || {};
  if(!content) return res.status(400).json({allowed:false, reason:'no content'});
  const banned = /(fuck|shit|badword)/i.test(content);
  res.status(200).json({allowed: !banned, reason: banned ? 'contains profanity' : 'clean'});
}
