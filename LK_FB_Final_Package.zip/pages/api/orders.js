let ORDERS = [];
export default function handler(req, res) {
  if(req.method === 'GET') return res.status(200).json(ORDERS);
  if(req.method === 'POST') {
    const order = req.body;
    order.id = Date.now();
    ORDERS.push(order);
    return res.status(201).json(order);
  }
  res.status(405).end();
}
