export default function Custom404() { return <h1 style={{color:'#fff',background:'#000',minHeight:'100vh'}}>404 — Page not found</h1> }
