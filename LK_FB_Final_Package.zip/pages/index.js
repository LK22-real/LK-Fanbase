export default function Home() {
  return (
    <main style={{background:'#000',color:'#fff',minHeight:'100vh',padding:20,fontFamily:'Inter, sans-serif'}}>
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div style={{fontWeight:800,fontSize:22}}>LK_FB</div>
        <nav><a style={{color:'#fff'}} href="/api/health">Health</a></nav>
      </header>
      <section style={{marginTop:40}}>
        <h1>Welcome to LK_FB</h1>
        <p>The ultimate fanbase for LK22. This package is preconfigured for Vercel with safety defaults.</p>
      </section>
    </main>
  )
}
